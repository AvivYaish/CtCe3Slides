Settlement Manipulation in Prediction Markets
David Dai, Ruizhe Jia, Shihao Yu. CBER, October 29, 2026.

How to open
1. Unzip this folder anywhere.
2. Double-click index.html (Google Chrome recommended). No internet or server is needed.

Controls
Next: click, Right arrow, Space.  Back: Left arrow.
G: scene grid.  Digits + Enter: jump to a scene.  F: fullscreen.  H or ?: all keys.
The opening scene plays a short video with sound after the first click.
Scenes marked "Appendix" are backup material after the main talk.
