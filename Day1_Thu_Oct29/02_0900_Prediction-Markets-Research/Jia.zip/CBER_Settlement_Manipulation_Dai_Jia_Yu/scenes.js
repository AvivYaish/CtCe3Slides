window.SCENES = {
 "title": "Settlement Manipulation in Prediction Markets",
 "scenes": [
  {
   "title": "Title",
   "file": "scenes/S00.html",
   "duration_s": 8,
   "beats": [
    {
     "t": 0.0
    }
   ]
  },
  {
   "title": "Cold open: three markets, three questions",
   "file": "scenes/S01.html",
   "duration_s": 45,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 10.4
    },
    {
     "t": 18.4
    },
    {
     "t": 24.4
    },
    {
     "t": 31
    },
    {
     "t": 35.5
    },
    {
     "t": 40
    }
   ]
  },
  {
   "title": "One price at the close",
   "file": "scenes/S02.html",
   "duration_s": 30,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 8
    },
    {
     "t": 20
    },
    {
     "t": 25
    }
   ]
  },
  {
   "title": "Their promises, and the regulator's worry",
   "file": "scenes/S04.html",
   "duration_s": 34,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 8.4
    },
    {
     "t": 15
    }
   ]
  },
  {
   "title": "Price discovery?",
   "file": "scenes/S04a.html",
   "duration_s": 32,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 6
    },
    {
     "t": 12.5
    },
    {
     "t": 20
    },
    {
     "t": 27
    }
   ]
  },
  {
   "title": "Good for ordinary traders?",
   "file": "scenes/S04b.html",
   "duration_s": 32,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 8
    },
    {
     "t": 17
    },
    {
     "t": 23
    },
    {
     "t": 28
    }
   ]
  },
  {
   "title": "Hard to manipulate?",
   "file": "scenes/S04c.html",
   "duration_s": 13,
   "beats": [
    {
     "t": 0
    }
   ]
  },
  {
   "title": "What ties the prediction market to Binance?",
   "file": "scenes/S05.html",
   "duration_s": 37,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 5
    },
    {
     "t": 11
    },
    {
     "t": 17
    },
    {
     "t": 28
    },
    {
     "t": 33
    }
   ]
  },
  {
   "title": "A 99% favourite, flipped in 10 seconds",
   "file": "scenes/S06b.html",
   "duration_s": 42,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 7
    },
    {
     "t": 11
    },
    {
     "t": 19
    },
    {
     "t": 27
    },
    {
     "t": 33
    }
   ]
  },
  {
   "title": "The puzzle",
   "file": "scenes/S06c.html",
   "duration_s": 11,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 4
    }
   ]
  },
  {
   "title": "What to remember",
   "file": "scenes/S07.html",
   "duration_s": 65,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 10
    },
    {
     "t": 31
    },
    {
     "t": 41
    },
    {
     "t": 52
    }
   ]
  },
  {
   "title": "Literature review",
   "file": "scenes/S08.html",
   "duration_s": 64,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 26
    },
    {
     "t": 46
    }
   ]
  },
  {
   "title": "Literature review: crypto and liquidity",
   "file": "scenes/S08b.html",
   "duration_s": 21,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 10
    }
   ]
  },
  {
   "title": "The model",
   "file": "scenes/M00.html",
   "duration_s": 5,
   "beats": [
    {
     "t": 0.0
    }
   ]
  },
  {
   "title": "Only a spot market",
   "file": "scenes/M01.html",
   "duration_s": 37,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 7.0
    },
    {
     "t": 13.0
    },
    {
     "t": 19.0
    },
    {
     "t": 26.0
    },
    {
     "t": 32.0
    }
   ]
  },
  {
   "title": "Trades carry news",
   "file": "scenes/M02.html",
   "duration_s": 34,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 8.0
    },
    {
     "t": 12.0
    },
    {
     "t": 19.0
    },
    {
     "t": 25.0
    },
    {
     "t": 31.0
    }
   ]
  },
  {
   "title": "A contract that reads the close",
   "file": "scenes/M03.html",
   "duration_s": 77,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 9.0
    },
    {
     "t": 16.0
    },
    {
     "t": 30.0
    },
    {
     "t": 40.0
    },
    {
     "t": 51.0
    },
    {
     "t": 61.0
    },
    {
     "t": 71.0
    }
   ]
  },
  {
   "title": "Last trade: rescue or push",
   "file": "scenes/M04m.html",
   "duration_s": 66,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 12.0
    },
    {
     "t": 26.0
    },
    {
     "t": 40.0
    },
    {
     "t": 59.0
    }
   ]
  },
  {
   "title": "One cycle, played out",
   "file": "scenes/M05a.html",
   "duration_s": 62,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 6.0
    },
    {
     "t": 16.0
    },
    {
     "t": 21.0
    },
    {
     "t": 33.0
    },
    {
     "t": 46.0
    },
    {
     "t": 53.0
    }
   ]
  },
  {
   "title": "Equilibrium, formally",
   "file": "scenes/M05c.html",
   "duration_s": 53,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 10.0
    },
    {
     "t": 17.0
    },
    {
     "t": 33.0
    },
    {
     "t": 39.0
    }
   ]
  },
  {
   "title": "The maker sees her coming",
   "file": "scenes/M06.html",
   "duration_s": 77,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 6.0
    },
    {
     "t": 10.0
    },
    {
     "t": 17.0
    },
    {
     "t": 28.0
    },
    {
     "t": 40.0
    },
    {
     "t": 47.0
    },
    {
     "t": 60.0
    }
   ]
  },
  {
   "title": "How often to manipulate? The frequency trade-off",
   "file": "scenes/M07.html",
   "duration_s": 48,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 5.0
    },
    {
     "t": 10.0
    },
    {
     "t": 20.0
    },
    {
     "t": 28.0
    },
    {
     "t": 36.0
    }
   ]
  },
  {
   "title": "Does the price still learn?",
   "file": "scenes/M08.html",
   "duration_s": 48,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 6.5
    },
    {
     "t": 15.5
    },
    {
     "t": 24.5
    },
    {
     "t": 32.5
    }
   ]
  },
  {
   "title": "Why not charge more?",
   "file": "scenes/M09.html",
   "duration_s": 51,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 14.0
    },
    {
     "t": 24.0
    },
    {
     "t": 32.0
    },
    {
     "t": 40.0
    }
   ]
  },
  {
   "title": "No manipulator: a fair 50/50",
   "file": "scenes/M10a.html",
   "duration_s": 45,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 9.0
    },
    {
     "t": 16.0
    },
    {
     "t": 21.5
    },
    {
     "t": 30.0
    },
    {
     "t": 34.0
    },
    {
     "t": 41.0
    }
   ]
  },
  {
   "title": "The rescue pays less",
   "file": "scenes/M10.html",
   "duration_s": 68,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 12.0
    },
    {
     "t": 21.0
    },
    {
     "t": 30.0
    },
    {
     "t": 36.0
    },
    {
     "t": 44.0
    },
    {
     "t": 56.0
    }
   ]
  },
  {
   "title": "Where the loss goes",
   "file": "scenes/M11.html",
   "duration_s": 43,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 8.0
    },
    {
     "t": 15.0
    },
    {
     "t": 26.0
    },
    {
     "t": 35.0
    }
   ]
  },
  {
   "title": "Does a longer clock help?",
   "file": "scenes/M12.html",
   "duration_s": 98,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 12.0
    },
    {
     "t": 28.0
    },
    {
     "t": 44.0
    },
    {
     "t": 55.0
    },
    {
     "t": 65.0
    },
    {
     "t": 77.0
    }
   ]
  },
  {
   "title": "A natural experiment: the 5-minute launch",
   "file": "scenes/S16.html",
   "duration_s": 53,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 13
    },
    {
     "t": 20
    },
    {
     "t": 40
    }
   ]
  },
  {
   "title": "Symptom 1: a last-second jump",
   "file": "scenes/S17.html",
   "duration_s": 70,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 13
    },
    {
     "t": 22
    },
    {
     "t": 28
    },
    {
     "t": 37
    },
    {
     "t": 50
    },
    {
     "t": 58
    }
   ]
  },
  {
   "title": "Symptom 2: where the outcome can flip",
   "file": "scenes/S18.html",
   "duration_s": 67,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 8
    },
    {
     "t": 22
    },
    {
     "t": 33
    },
    {
     "t": 47
    }
   ]
  },
  {
   "title": "Symptom 3: the spot looks more liquid",
   "file": "scenes/S18b.html",
   "duration_s": 33,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 12
    },
    {
     "t": 27
    }
   ]
  },
  {
   "title": "Symptom 4: a push partly comes back",
   "file": "scenes/S19.html",
   "duration_s": 69,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 8
    },
    {
     "t": 15
    },
    {
     "t": 23
    },
    {
     "t": 30
    },
    {
     "t": 49
    },
    {
     "t": 64
    }
   ]
  },
  {
   "title": "Which cycles get pushed?",
   "file": "scenes/S20a.html",
   "duration_s": 37,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 7
    },
    {
     "t": 20
    },
    {
     "t": 31
    }
   ]
  },
  {
   "title": "Against a 90% favourite, the underdog wins 1 in 3",
   "file": "scenes/S20b.html",
   "duration_s": 48,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 14
    },
    {
     "t": 28
    },
    {
     "t": 38
    }
   ]
  },
  {
   "title": "Who pays, in the data?",
   "file": "scenes/S21.html",
   "duration_s": 68,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 17
    },
    {
     "t": 32
    },
    {
     "t": 48
    },
    {
     "t": 60
    }
   ]
  },
  {
   "title": "Does a longer clock help?",
   "file": "scenes/S23.html",
   "duration_s": 34,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 17
    },
    {
     "t": 25
    },
    {
     "t": 30
    }
   ]
  },
  {
   "title": "June 30: we measured it, in public",
   "file": "scenes/I1.html",
   "duration_s": 18,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 5
    },
    {
     "t": 9
    }
   ]
  },
  {
   "title": "Then it spread",
   "file": "scenes/I2.html",
   "duration_s": 36,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 10
    },
    {
     "t": 19
    },
    {
     "t": 28
    }
   ]
  },
  {
   "title": "Polymarket answered, in public",
   "file": "scenes/I3.html",
   "duration_s": 27,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 13
    },
    {
     "t": 22
    }
   ]
  },
  {
   "title": "They changed the rule, then made it longer",
   "file": "scenes/I4.html",
   "duration_s": 26,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 6
    },
    {
     "t": 14
    },
    {
     "t": 22
    }
   ]
  },
  {
   "title": "Late August to September: the burst faded",
   "file": "scenes/I5.html",
   "duration_s": 43,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 14
    },
    {
     "t": 25
    },
    {
     "t": 35
    }
   ]
  },
  {
   "title": "Bookend and hand-off",
   "file": "scenes/S29.html",
   "duration_s": 64,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 14
    },
    {
     "t": 28
    },
    {
     "t": 44
    },
    {
     "t": 50
    },
    {
     "t": 58
    }
   ]
  },
  {
   "title": "Appendix · Not hedging: too late, too big",
   "file": "scenes/S22.html",
   "duration_s": 65,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 7
    },
    {
     "t": 19
    },
    {
     "t": 27
    },
    {
     "t": 42
    },
    {
     "t": 58
    }
   ]
  },
  {
   "title": "Appendix · The wall: same payout, different settlement prices",
   "file": "scenes/S03.html",
   "duration_s": 24,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 7
    },
    {
     "t": 12
    },
    {
     "t": 17
    }
   ]
  },
  {
   "title": "Appendix · What we claim, and what we do not",
   "file": "scenes/S28.html",
   "duration_s": 40,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 7
    },
    {
     "t": 14
    },
    {
     "t": 30
    }
   ]
  },
  {
   "title": "Appendix · Three promises, crossed",
   "file": "scenes/S04d.html",
   "duration_s": 63,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 5
    },
    {
     "t": 17
    },
    {
     "t": 22
    },
    {
     "t": 33
    },
    {
     "t": 44
    },
    {
     "t": 51
    }
   ]
  },
  {
   "title": "Appendix · What happens in the last 10 seconds?",
   "file": "scenes/S06.html",
   "duration_s": 52,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 9
    },
    {
     "t": 16
    },
    {
     "t": 27
    },
    {
     "t": 38
    },
    {
     "t": 46
    }
   ]
  },
  {
   "title": "Appendix · How she makes the odds unfair",
   "file": "scenes/M10b.html",
   "duration_s": 40,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 12.0
    },
    {
     "t": 18.0
    }
   ]
  },
  {
   "title": "Appendix · Who chooses?",
   "file": "scenes/M05b.html",
   "duration_s": 87,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 11.0
    },
    {
     "t": 22.0
    },
    {
     "t": 27.0
    },
    {
     "t": 36.0
    },
    {
     "t": 45.0
    },
    {
     "t": 52.0
    },
    {
     "t": 60.0
    },
    {
     "t": 67.0
    },
    {
     "t": 75.0
    }
   ]
  },
  {
   "title": "Appendix · What the model says",
   "file": "scenes/M13.html",
   "duration_s": 86,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 8.0
    },
    {
     "t": 30.0
    },
    {
     "t": 41.0
    },
    {
     "t": 52.0
    },
    {
     "t": 71.0
    }
   ]
  },
  {
   "title": "Appendix · Equilibrium, in plain words",
   "file": "scenes/M05d.html",
   "duration_s": 38,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 12.0
    },
    {
     "t": 20.0
    },
    {
     "t": 31.0
    }
   ]
  },
  {
   "title": "Appendix · Sources",
   "file": "scenes/S30.html",
   "duration_s": 95,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 5.0
    },
    {
     "t": 10.0
    },
    {
     "t": 15.0
    },
    {
     "t": 20.0
    },
    {
     "t": 25.0
    },
    {
     "t": 30.0
    },
    {
     "t": 35.0
    },
    {
     "t": 40.0
    },
    {
     "t": 45.0
    },
    {
     "t": 50.0
    },
    {
     "t": 55.0
    },
    {
     "t": 60.0
    },
    {
     "t": 65.0
    },
    {
     "t": 70.0
    },
    {
     "t": 75.0
    },
    {
     "t": 80.0
    },
    {
     "t": 85.0
    },
    {
     "t": 90.0
    }
   ]
  },
  {
   "title": "Appendix · Formal results",
   "file": "scenes/MF.html",
   "duration_s": 56,
   "backup": true,
   "beats": [
    {
     "t": 0.0
    },
    {
     "t": 8.0
    },
    {
     "t": 16.0
    },
    {
     "t": 24.0
    },
    {
     "t": 32.0
    },
    {
     "t": 40.0
    },
    {
     "t": 48.0
    }
   ]
  },
  {
   "title": "Appendix · The contract's own book thins",
   "file": "scenes/S18c.html",
   "duration_s": 15,
   "backup": true,
   "beats": [
    {
     "t": 0
    },
    {
     "t": 4
    },
    {
     "t": 9
    }
   ]
  }
 ]
};
