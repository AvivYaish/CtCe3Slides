window.SOURCES_PAGES = [
[
{
"k": "h",
"s": "Act 1"
},
{
"k": "l",
"s": "2 · Kalshi launch ad, X, posted Jan 20, 2026 · prices in the ad are animated, not data"
},
{
"k": "l",
"s": "2 · Kalshi ad on Instagram, running since Sep 14, 2026 · Meta Ad Library ID 1047326131471208"
},
{
"k": "l",
"s": "2 · Cboe press release, Jun 23, 2026 (XSPBW/XSPBX, 0DTE and 1DTE) · SEC Release 34-105342, Apr 30,"
},
{
"k": "l",
"s": "      2026: Nasdaq MRX binaries on the Nasdaq-100 (OROs)"
},
{
"k": "l",
"s": "2 · Kalshi ad, X, Jan 20, 2026 · Kalshi ad, Instagram, Ad Library 1047326131471208 (DOWN button"
},
{
"k": "l",
"s": "      greyed) · Cboe release, Jun 23, 2026"
},
{
"k": "l",
"s": "3 · Paths: illustration, not data. K: a target set before trading."
},
{
"k": "l",
"s": "3 · K: Cboe XSPBW strikes, 80–110% of prior close (FAQ) · Nasdaq ORO strikes (34-105342) · up/down:"
},
{
"k": "l",
"s": "      K = P_open · Kalshi: 60-s BRTI averages"
},
{
"k": "l",
"s": "4 · Cboe, Release 34-105247 (Apr 2026); Nasdaq, Release 34-105342 (Apr 30, 2026), p.4; SEC, same"
},
{
"k": "l",
"s": "      release, p.27."
},
{
"k": "l",
"s": "4 · Nasdaq, Release 34-105342 (Apr 30, 2026), p.4; CME self-certification (Nov 19, 2025)."
},
{
"k": "l",
"s": "5 · Definition: price discovery is how close the price is to the true value, measured as the"
},
{
"k": "l",
"s": "      expected squared distance of the price from the value (Zhu, Review of Financial Studies 2014,"
},
{
"k": "l",
"s": "      pp. 765-766; Kyle 1985; Dai, Jia & Yu (2026), Section 4: the expected residual variance of V"
},
{
"k": "l",
"s": "      given the settlement-time price)."
},
{
"k": "l",
"s": "5 · Picture: each dot is one five-minute cycle's settlement price drawn at its miss from that"
},
{
"k": "l",
"s": "      cycle's own true value; the line is every cycle's own value laid on one axis. Not a price"
},
{
"k": "l",
"s": "      path: the price itself varies less across outcomes; its miss from the value varies more."
}
],
[
{
"k": "h",
"s": "Act 1 (continued)"
},
{
"k": "l",
"s": "5 · Dai, Jia & Yu (2026), Prop. 3: with the prediction market, the expected doubt about V left at"
},
{
"k": "l",
"s": "      settlement is strictly larger than without it, for every entry probability in (0,1) and every"
},
{
"k": "l",
"s": "      push profile, even when she never pushes. Sign only, an average over cycles. The paper's"
},
{
"k": "l",
"s": "      illustration: 0.8349 to 0.8396 (under 1%); the drawn widening is not to scale."
},
{
"k": "l",
"s": "5 · Hope: exchanges promise price discovery (Nasdaq, Release 34-105342, p.4: \"a centralized forum"
},
{
"k": "l",
"s": "      for price discovery\", about its own listing). Zhu (2014): a second venue sharpens the main"
},
{
"k": "l",
"s": "      market's price only under certain conditions. The question here is the settlement price; the"
},
{
"k": "l",
"s": "      narrower dashed band is a hope, not a size."
},
{
"k": "l",
"s": "6 · Their words: Cboe, Release 34-105247, p.18: binaries “will benefit investors, particularly"
},
{
"k": "l",
"s": "      retail investors”."
},
{
"k": "l",
"s": "6 · Dai, Jia & Yu (2026), Section 4. Prop. 4(iv): posted prediction-market quotes A1 = B1 = 1/2"
},
{
"k": "l",
"s": "      (zero spread). Prop. 5: L+ = 1/2 − Pi_L+ > 0, the ordinary Up buyer's expected loss per order;"
},
{
"k": "l",
"s": "      Pi_L+ is the Up contract's win chance (payoff 1 or 0)."
},
{
"k": "l",
"s": "6 · Model illustration (sigma = 1, pi = 0.3, eps = 0.1): L+ = 0.0291; 47 heads in 100 = 100 × (0.5 −"
},
{
"k": "l",
"s": "      0.0291) = 47.09, an expected rate drawn as one round of 100 flips; which flips land heads is a"
},
{
"k": "l",
"s": "      seeded draw. Pay $50 for 100 contracts at 50¢, get back 47.09 × $1 = $47.09, our arithmetic."
},
{
"k": "l",
"s": "      The model has no trading fee; 'before fees' is the talk's framing. For an Up liquidity buyer"
},
{
"k": "l",
"s": "      only."
}
],
[
{
"k": "h",
"s": "Act 1 (continued)"
},
{
"k": "l",
"s": "7 · Dai, Jia & Yu, Table 1 (P3 medians, Feb 12 - Apr 8, 2026): Binance BTC spot volume $3.15M per"
},
{
"k": "l",
"s": "      5-min cycle (N = 16,128); Polymarket 104.9k $1-face shares per cycle (N = 16,073), shown as"
},
{
"k": "l",
"s": "      $105k. Squares to scale by area (dollars). The ~30x size gap by face value is ours."
},
{
"k": "h",
"s": "Act 2"
},
{
"k": "l",
"s": "8 · Dai, Jia & Yu, Table 1, P3 medians (Feb 12 - Apr 8, 2026): Binance BTC spot volume $3.15M per"
},
{
"k": "l",
"s": "      5-min cycle (N = 16,128); Polymarket 104.9k $1-face shares per cycle (N = 16,073), shown as"
},
{
"k": "l",
"s": "      $105k face value. Ratio about 30 by face value (ours; the paper: 'a factor of thirty')."
},
{
"k": "l",
"s": "      Squares to scale by area (dollars), as in S04c; the strip in the last click is time (0-300 s),"
},
{
"k": "l",
"s": "      a separate picture."
},
{
"k": "l",
"s": "8 · Settlement: Chainlink BTC/USD data stream, which aggregates many venues; one reading at the open"
},
{
"k": "l",
"s": "      (price to beat) and one at the close until Aug 7, 2026, when Polymarket switched to a"
},
{
"k": "l",
"s": "      30-second Chainlink average (paper Section 2 and footnote; Polymarket market text: 'according"
},
{
"k": "l",
"s": "      to Chainlink data stream BTC/USD, not according to other sources or spot markets')."
},
{
"k": "l",
"s": "8 · 85%: share of BTC 5-minute cycles where Binance's mid at the close and the settlement price fall"
},
{
"k": "l",
"s": "      on the same side of the price to beat (84.8%); only cycles with both Chainlink prices known, n"
},
{
"k": "l",
"s": "      = 5,553 (paper Appendix, Binance vs Chainlink validation). Association, not price impact."
},
{
"k": "l",
"s": "9 · Cycle 2026-03-12 04:45 UTC (btc-updown-5m-1773290700), picked on the outcome: PushIntensity"
},
{
"k": "l",
"s": "      372.7 vs the 16.11 cut. Binance BTCUSDT vs its own open; net taker flow from aggTrades."
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "9 · Chainlink 69,386.11 to 69,389.27 (+3.15), Up won (gamma outcomePrices [1,0]). Count: pushed"
},
{
"k": "l",
"s": "      cycles, favourite >= 90% at 10 s left, underdog won: 304 x 34.2% = 104 (Table 9); replication"
},
{
"k": "l",
"s": "      101 in 56 days."
},
{
"k": "l",
"s": "12 · Kumar, P. & Seppi, D. J. (1992), “Futures Manipulation with ‘Cash Settlement’”, Journal of"
},
{
"k": "l",
"s": "      Finance 47(4), 1485-1502. doi:10.1111/j.1540-6261.1992.tb04666.x"
},
{
"k": "l",
"s": "12 · Jarrow, R. A. (1994), “Derivative Security Markets, Market Manipulation, and Option Pricing"
},
{
"k": "l",
"s": "      Theory”, JFQA 29(2), 241-261. doi:10.2307/2331224"
},
{
"k": "l",
"s": "12 · Muermann, A. & Shore, S. H. (2006), “Strategic Trading and Manipulation with Spot Market"
},
{
"k": "l",
"s": "      Power”, CFS Working Paper 2006/07. econstor.eu/bitstream/10419/25473/1/515334006.PDF"
},
{
"k": "l",
"s": "12 · Zhang, A. L. (2022), “Competition and Manipulation in Derivative Contract Markets”, Journal of"
},
{
"k": "l",
"s": "      Financial Economics 144(2), 396-413. doi:10.1016/j.jfineco.2022.02.001"
},
{
"k": "l",
"s": "12 · Ni, S. X., Pearson, N. D. & Poteshman, A. M. (2005), “Stock Price Clustering on Option"
},
{
"k": "l",
"s": "      Expiration Dates”, Journal of Financial Economics 78(1), 49-87."
},
{
"k": "l",
"s": "      doi:10.1016/j.jfineco.2004.08.005"
},
{
"k": "l",
"s": "12 · Comerton-Forde, C. & Putniņš, T. J. (2011), “Measuring Closing Price Manipulation”, Journal of"
},
{
"k": "l",
"s": "      Financial Intermediation 20(2), 135-158. doi:10.1016/j.jfi.2010.03.003"
},
{
"k": "l",
"s": "12 · Griffin, J. M. & Shams, A. (2018), “Manipulation in the VIX?”, Review of Financial Studies"
},
{
"k": "l",
"s": "      31(4), 1377-1417. doi:10.1093/rfs/hhx085"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "12 · Baltussen, G., Terstegge, J. & Whelan, P. (2023), “The Derivative Payoff Bias”, SSRN working"
},
{
"k": "l",
"s": "      paper 4562800. doi:10.2139/ssrn.4562800"
},
{
"k": "l",
"s": "12 · Kyle, A. S. & Viswanathan, S. (2008), “How to Define Illegal Price Manipulation”, American"
},
{
"k": "l",
"s": "      Economic Review P&P 98(2), 274-279. doi:10.1257/aer.98.2.274"
},
{
"k": "l",
"s": "12 · Duffie, D. & Stein, J. C. (2015), “Reforming LIBOR and Other Financial Market Benchmarks”,"
},
{
"k": "l",
"s": "      Journal of Economic Perspectives 29(2), 191-212. doi:10.1257/jep.29.2.191"
},
{
"k": "l",
"s": "12 · Duffie, D. & Dworczak, P. (2021), “Robust Benchmark Design”, Journal of Financial Economics"
},
{
"k": "l",
"s": "      142(2), 775-802. doi:10.1016/j.jfineco.2021.06.024"
},
{
"k": "l",
"s": "12 · Wolfers, J. & Zitzewitz, E. (2004), “Prediction Markets”, Journal of Economic Perspectives"
},
{
"k": "l",
"s": "      18(2), 107-126. doi:10.1257/0895330041371321"
},
{
"k": "l",
"s": "12 · Hanson, R., Oprea, R. & Porter, D. (2006), “Information Aggregation and Manipulation in an"
},
{
"k": "l",
"s": "      Experimental Market”, JEBO 60(4), 449-459. doi:10.1016/j.jebo.2004.09.011"
},
{
"k": "l",
"s": "12 · Rhode, P. W. & Strumpf, K. S., “Manipulating Political Stock Markets: A Field Experiment and a"
},
{
"k": "l",
"s": "      Century of Observational Data”, working paper (2006 version found:"
},
{
"k": "l",
"s": "      s3.amazonaws.com/fieldexperiments-papers2/papers/00325.pdf). Year 2008 and the NBER number:"
},
{
"k": "l",
"s": "      UNVERIFIED (NBER w14377 is a different paper)."
},
{
"k": "l",
"s": "12 · Hanson, R. & Oprea, R. (2009), “A Manipulator Can Aid Prediction Market Accuracy”, Economica"
},
{
"k": "l",
"s": "      76(302), 304-314. doi:10.1111/j.1468-0335.2008.00734.x"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "12 · Snowberg, E., Wolfers, J. & Zitzewitz, E. (2013), “Prediction Markets for Economic"
},
{
"k": "l",
"s": "      Forecasting”, Handbook of Economic Forecasting vol. 2, 657-687."
},
{
"k": "l",
"s": "      doi:10.1016/B978-0-444-53683-9.00011-6"
},
{
"k": "l",
"s": "12 · Berg, J. E. & Rietz, T. A. (2014), “Market Design, Manipulation, and Accuracy in Political"
},
{
"k": "l",
"s": "      Prediction Markets”, PS: Political Science & Politics 47(2), 293-296."
},
{
"k": "l",
"s": "      doi:10.1017/s1049096514000043"
},
{
"k": "l",
"s": "12 · Hansen, J., Schmidt, C. & Strobel, M. (2004), “Manipulation in Political Stock Markets:"
},
{
"k": "l",
"s": "      Preconditions and Evidence”, Applied Economics Letters 11(7), 459-463."
},
{
"k": "l",
"s": "      doi:10.1080/1350485042000191700"
},
{
"k": "l",
"s": "12 · Ottaviani, M. & Sørensen, P. N. (2007), “Outcome Manipulation in Corporate Prediction Markets”,"
},
{
"k": "l",
"s": "      JEEA 5(2-3), 554-563. doi:10.1162/jeea.2007.5.2-3.554"
},
{
"k": "l",
"s": "12 · Deck, C., Lin, S. & Porter, D. (2013), “Affecting Policy by Manipulating Prediction Markets:"
},
{
"k": "l",
"s": "      Experimental Evidence”, JEBO 85, 48-62. doi:10.1016/j.jebo.2012.10.017"
},
{
"k": "l",
"s": "12 · Rothschild, D. M. & Sethi, R., “Trading Strategies and Market Microstructure: Evidence from a"
},
{
"k": "l",
"s": "      Prediction Market”, SSRN 2322420 (2013), doi:10.2139/ssrn.2322420. Journal version (J."
},
{
"k": "l",
"s": "      Prediction Markets 10(1), 2016): UNVERIFIED on 2026-10-28."
},
{
"k": "l",
"s": "12 · Choo, L., Kaplan, T. R. & Zultan, R. (2022), “Manipulation and (Mis)trust in Prediction"
},
{
"k": "l",
"s": "      Markets”, Management Science 68(9), 6716-6732. doi:10.1287/mnsc.2021.4213"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "12 · Rasooly, I. & Rozzi, R. (2025), “How Manipulable Are Prediction Markets?”, arXiv 2503.03312."
},
{
"k": "l",
"s": "      arxiv.org/abs/2503.03312"
},
{
"k": "l",
"s": "12 · Bartlett, R. P. & O’Hara, M. (2026), “Adverse Selection in Prediction Markets: Evidence from"
},
{
"k": "l",
"s": "      Kalshi”, SSRN 6615739. doi:10.2139/ssrn.6615739"
},
{
"k": "l",
"s": "12 · Akey, P., Grégoire, V., Harvie, N. & Martineau, C. (2026), “Who Wins and Who Loses in"
},
{
"k": "l",
"s": "      Prediction Markets? Evidence from Polymarket”, SSRN 6443103. doi:10.2139/ssrn.6443103"
},
{
"k": "l",
"s": "12 · Gómez-Cram, R., Guo, Y., Jensen, T. I. & Kung, H. (2026), “Prediction Market Accuracy: Crowd"
},
{
"k": "l",
"s": "      Wisdom or Informed Minority?”, SSRN 6617059. doi:10.2139/ssrn.6617059"
},
{
"k": "l",
"s": "12 · Della Vedova, J. (2026), “Who Profits from Prediction Markets? Execution, not Information”,"
},
{
"k": "l",
"s": "      SSRN 6191618. doi:10.2139/ssrn.6191618"
},
{
"k": "l",
"s": "12 · Bürgi, C., Deng, W. & Whelan, K. (2025), “Makers and Takers: The Economics of the Kalshi"
},
{
"k": "l",
"s": "      Prediction Market”, CESifo Working Paper 12122 (MPRA 126350, 2025). doi:10.65864/s9kc4p0b7t"
},
{
"k": "l",
"s": "12 · Diercks, A. M., Katz, J. D. & Wright, J. H. (2026), “Kalshi and the Rise of Macro Markets”,"
},
{
"k": "l",
"s": "      NBER Working Paper 34702. doi:10.3386/w34702"
},
{
"k": "l",
"s": "12 · Tsang, K. P. & Yang, Z. (2026), “The Anatomy of a Blockchain Prediction Market: Polymarket in"
},
{
"k": "l",
"s": "      the 2024 U.S. Presidential Election”, arXiv 2603.03136. arxiv.org/abs/2603.03136"
},
{
"k": "l",
"s": "12 · Dubach, P. D. (2026), “The Anatomy of a Decentralized Prediction Market: Microstructure"
},
{
"k": "l",
"s": "      Evidence from the Polymarket Order Book”, arXiv 2604.24366. arxiv.org/abs/2604.24366"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "12 · Ng, H., Peng, L., Tao, Y. & Zhou, D. (2025), “Price Discovery and Trading in Modern Prediction"
},
{
"k": "l",
"s": "      Markets”, SSRN 5331995. doi:10.2139/ssrn.5331995"
},
{
"k": "l",
"s": "12 · Saguillo, O., Ghafouri, V., Kiffer, L. & Suarez-Tangil, G. (2025), “Unravelling the"
},
{
"k": "l",
"s": "      Probabilistic Forest: Arbitrage in Prediction Markets”, arXiv 2508.03474."
},
{
"k": "l",
"s": "      arxiv.org/abs/2508.03474"
},
{
"k": "l",
"s": "12 · Sirolly, A., Ma, H., Kanoria, Y. & Sethi, R. (2025), “Network-Based Detection of Wash Trading”,"
},
{
"k": "l",
"s": "      SSRN 5714122. doi:10.2139/ssrn.5714122"
},
{
"k": "l",
"s": "13 · Easley, D., O’Hara, M. & Basu, S. (2019), “From Mining to Markets: The Evolution of Bitcoin"
},
{
"k": "l",
"s": "      Transaction Fees”, Journal of Financial Economics 134(1), 91-109."
},
{
"k": "l",
"s": "      doi:10.1016/j.jfineco.2019.03.004"
},
{
"k": "l",
"s": "13 · Makarov, I. & Schoar, A. (2020), “Trading and Arbitrage in Cryptocurrency Markets”, Journal of"
},
{
"k": "l",
"s": "      Financial Economics 135(2), 293-319. doi:10.1016/j.jfineco.2019.07.001"
},
{
"k": "l",
"s": "13 · Griffin, J. M. & Shams, A. (2020), “Is Bitcoin Really Untethered?”, Journal of Finance 75(4),"
},
{
"k": "l",
"s": "      1913-1964. doi:10.1111/jofi.12903"
},
{
"k": "l",
"s": "13 · Lehar, A. & Parlour, C. A. (2022a), “Miner Collusion and the Bitcoin Protocol”, working paper"
},
{
"k": "l",
"s": "      (draft of 2022-10-06). economics.yale.edu/sites/default/files/2022-11/parlour-miner-collusion-"
},
{
"k": "l",
"s": "      and-bitcoin-protocol.pdf"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "13 · Easley, D., O’Hara, M., Yang, S. & Zhang, Z. (2026), “Microstructure and Market Dynamics in"
},
{
"k": "l",
"s": "      Crypto Markets”, Journal of Financial Markets, 101071 (working paper SSRN 4814346, 2024)."
},
{
"k": "l",
"s": "      doi:10.1016/j.finmar.2026.101071"
},
{
"k": "l",
"s": "13 · Lehar, A. & Parlour, C. A. (2022b), “Systemic Fragility in Decentralized Markets”, BIS Working"
},
{
"k": "l",
"s": "      Paper 1062. bis.org/publ/work1062.pdf"
},
{
"k": "l",
"s": "13 · Lehar, A. & Parlour, C. A. (2025), “Decentralized Exchange: The Uniswap Automated Market"
},
{
"k": "l",
"s": "      Maker”, Journal of Finance 80(1), 321-374. doi:10.1111/jofi.13405"
},
{
"k": "l",
"s": "13 · Park, A. (2023), “The Conceptual Flaws of Decentralized Automated Market Making”, Management"
},
{
"k": "l",
"s": "      Science 69(11), 6731-6751. doi:10.1287/mnsc.2021.02802"
},
{
"k": "l",
"s": "13 · Hasbrouck, J., Rivera, T. J. & Saleh, F., “An Economic Model of a Decentralized Exchange with"
},
{
"k": "l",
"s": "      Concentrated Liquidity”, Management Science 72(5), 3666-3683 (2026 issue; tag year 2024 = the"
},
{
"k": "l",
"s": "      paper’s cite key). doi:10.1287/mnsc.2024.04510"
},
{
"k": "l",
"s": "13 · Capponi, A. & Jia, R. (2025), “Liquidity Provision on Blockchain-Based Decentralized"
},
{
"k": "l",
"s": "      Exchanges”, Review of Financial Studies 38(10), 3040-3085. doi:10.1093/rfs/hhaf046"
},
{
"k": "l",
"s": "13 · Eskandari, S., Salehi, M., Gu, W. C. & Clark, J. (2021), “SoK: Oracles from the Ground Truth to"
},
{
"k": "l",
"s": "      Market Manipulation”, ACM AFT 2021, 127-141. doi:10.1145/3479722.3480994"
},
{
"k": "l",
"s": "13 · Mackinga, T., Nadahalli, T. & Wattenhofer, R. (2022), “TWAP Oracle Attacks: Easier Done than"
},
{
"k": "l",
"s": "      Said?”, IEEE ICBC 2022, 1-8. doi:10.1109/ICBC54727.2022.9805499"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "13 · Cong, L. W., Prasad, E. S. & Rabetti, D. (2025), “Financial and Informational Integration"
},
{
"k": "l",
"s": "      Through Oracle Networks”, NBER Working Paper 33639. doi:10.3386/w33639"
},
{
"k": "l",
"s": "13 · Nadler, M., Schuler, K. & Schär, F. (2025), “Blockchain Price Oracles: Accuracy and Violation"
},
{
"k": "l",
"s": "      Recovery”, Journal of Corporate Finance 96, 102908. doi:10.1016/j.jcorpfin.2025.102908"
},
{
"k": "l",
"s": "13 · Glosten, L. R. & Milgrom, P. R. (1985), “Bid, Ask and Transaction Prices in a Specialist Market"
},
{
"k": "l",
"s": "      with Heterogeneously Informed Traders”, JFE 14(1), 71-100. doi:10.1016/0304-405X(85)90044-3"
},
{
"k": "l",
"s": "13 · Admati, A. R. & Pfleiderer, P. (1988), “A Theory of Intraday Patterns: Volume and Price"
},
{
"k": "l",
"s": "      Variability”, Review of Financial Studies 1(1), 3-40. doi:10.1093/rfs/1.1.3"
},
{
"k": "l",
"s": "13 · Admati, A. R. & Pfleiderer, P. (1991), “Sunshine Trading and Financial Market Equilibrium”,"
},
{
"k": "l",
"s": "      Review of Financial Studies 4(3), 443-481. doi:10.1093/rfs/4.3.443"
},
{
"k": "l",
"s": "13 · Subrahmanyam, A. (1991), “A Theory of Trading in Stock Index Futures”, Review of Financial"
},
{
"k": "l",
"s": "      Studies 4(1), 17-51. doi:10.1093/rfs/4.1.17"
},
{
"k": "l",
"s": "13 · Chowdhry, B. & Nanda, V. (1991), “Multimarket Trading and Market Liquidity”, Review of"
},
{
"k": "l",
"s": "      Financial Studies 4(3), 483-511. doi:10.1093/rfs/4.3.483"
},
{
"k": "l",
"s": "13 · Easley, D., O’Hara, M. & Srinivas, P. S. (1998), “Option Volume and Stock Prices: Evidence on"
},
{
"k": "l",
"s": "      Where Informed Traders Trade”, Journal of Finance 53(2), 431-465. doi:10.1111/0022-1082.194060"
},
{
"k": "l",
"s": "13 · O’Hara, M. (2003), “Presidential Address: Liquidity and Price Discovery”, Journal of Finance"
},
{
"k": "l",
"s": "      58(4), 1335-1354. doi:10.1111/1540-6261.00569"
}
],
[
{
"k": "h",
"s": "Act 2 (continued)"
},
{
"k": "l",
"s": "13 · Cespa, G. & Foucault, T. (2014), “Illiquidity Contagion and Liquidity Crashes”, Review of"
},
{
"k": "l",
"s": "      Financial Studies 27(6), 1615-1660. doi:10.1093/rfs/hhu016"
},
{
"k": "h",
"s": "Model"
},
{
"k": "l",
"s": "15 · Model: Lemma 1 (stage-2 quotes), paper S/04:84-96; illustration σ = 1, π = 0.3."
},
{
"k": "l",
"s": "16 · Model: Prop 1 at p_M = 0 (stage-3 quotes), paper S/04:104-142; price-discovery measure"
},
{
"k": "l",
"s": "      S/04:212-217; illustration σ = 1, π = 0.3."
},
{
"k": "l",
"s": "17 · Model: settlement rule and H on the full path, paper S/03:42-89; Assumption 1, S/03:254-256;"
},
{
"k": "l",
"s": "      illustration"
},
{
"k": "l",
"s": "18 · Model: payoff H(V̄/ε), S/03:42-89; stage-3 ask after a sell = 0 = K when no push is expected,"
},
{
"k": "l",
"s": "      A:543-560, A:359-392; P(rescue) = (1 − π²)/2 = 0.455 (spoken); Γ_sell(0) = ½ − σπ = 0.2 > 0"
},
{
"k": "l",
"s": "      (spoken), S/04:152-168; illustration σ = 1, π = 0.3, ε = 0.1."
},
{
"k": "l",
"s": "19 · Model: timing and players S/03:91-206; settlement H(V̄/ε) S/03:42-89; stage-2 quotes ±σπ;"
},
{
"k": "l",
"s": "20 · Paper S/03, Definition 1 (211-228): (1) zero-profit quotes, non-crossing book; (2) Bayes on"
},
{
"k": "l",
"s": "      path; (3) best response."
},
{
"k": "l",
"s": "21 · Model: Prop 1, Cor 1 (S/04:104-148); Prop 4(ii) α*_buy = 0, α*_sell = 1 with Γ(1) = 0.372 −"
},
{
"k": "l",
"s": "      0.274 = 0.098 > 0 (A:342-392); illustration σ = 1, π = 0.3, ε = 0.1, p* = 0.0407."
},
{
"k": "l",
"s": "22 · Model: Prop 4(i),(iii), S/04:310-364, A:323-858; push-decision table, S/04:152-168, A:410-476;"
},
{
"k": "l",
"s": "      illustration σ = 1, π = 0.3, ε = 0.1."
}
],
[
{
"k": "h",
"s": "Model (continued)"
},
{
"k": "l",
"s": "23 · Model: Prop 3 (S/04:222-239; proof A:251-321); displacement and dilution (S/04:232; A:270-290);"
},
{
"k": "l",
"s": "      benchmark 83% = E[Σ] 0.8349 at p_M = 0, illustration σ = 1, π = 0.3. Sign, not size."
},
{
"k": "l",
"s": "24 · Model, n = 1: Π_M 0.686 gross of push cost (MF:236); Prop 4(iv) A1 = B1 = 1/2, zero spread"
},
{
"k": "l",
"s": "      (S/04:334-364); R_PM = 1/2 − A1-BE = 0.0204 (Prop 5, S/04:415-452; MF:292)."
},
{
"k": "l",
"s": "25 · *p*_{M} = 0; σ = 1, π = 0.3, ε = 0.1. Shares ½(1 ± π²)/2; last price ±0.55 or 0; H = 1, ½, ½,"
},
{
"k": "l",
"s": "      0; average ½ (paper S/03:73-90, S/04:84-120 at the limit *p*_{M} → 0)."
},
{
"k": "l",
"s": "26 · Model: Prop 5, Cor 1 (paper S/03:105-113, 199-206; S/04:104-148, 415-452); σ = 1, π = 0.3, ε ="
},
{
"k": "l",
"s": "      0.1: before (p_M → 0) ask after a sell 0, H = ½; after (p* = 0.0407) A*_sell = −0.0256, H ="
},
{
"k": "l",
"s": "      0.372; rescue path ½ · 0.455 = 0.2275; 27%·100 + 23%·50 + 23%·37 + 27%·0 = 47; Π_L = 0.471."
},
{
"k": "l",
"s": "27 · Model: Prop 5, (1 − p*)L⁺ = R⁺ + p*S⁺ + p*K⁺ (S/04:415-452); illustration σ = 1, π = 0.3, ε ="
},
{
"k": "l",
"s": "      0.1: 2.04 + 0.56 + 0.20 = 2.80¢."
},
{
"k": "l",
"s": "27 · Model illustration, our computation (not in the paper; same values): the push cost reaches the"
},
{
"k": "l",
"s": "      spot maker, which breaks even and cuts its ask after a sell; that cheaper ask goes about 77%"
},
{
"k": "l",
"s": "      to random and 23% to informed spot traders. Net, random spot traders gain 1.21¢ and the"
},
{
"k": "l",
"s": "      informed trader loses 0.66¢ per cycle."
},
{
"k": "l",
"s": "28 · Model: Props 7-8, paper S/04:995-1218, A:2700-2714, A:3685-3737; illustration π = 0.3, odd n;"
},
{
"k": "l",
"s": "      0.2¢ from M11."
}
],
[
{
"k": "h",
"s": "Evidence"
},
{
"k": "l",
"s": "29 · Source: Dai, Jia & Yu, Section 6.2 and Tables 1-2. Binance BTC spot; Polymarket BTC 5-minute"
},
{
"k": "l",
"s": "      contract. Before/after: P1 vs P3; P2 = 15-minute test."
},
{
"k": "l",
"s": "30 · Source: Dai, Jia & Yu, Fig. 8 left (averages), Table 2 cols. 1-3 (typical cycle; body = 0-250"
},
{
"k": "l",
"s": "      s). Binance BTC, P1 Jul-Oct 2025 vs P3 Feb 12-Apr 8, 2026."
},
{
"k": "l",
"s": "31 · Source: Dai, Jia & Yu, Fig. 10a (curves = averages), Table 4 col. 1 (typical cycle), P3. Coin-"
},
{
"k": "l",
"s": "      flip: Up 40-60¢ at 10-12 s before the close."
},
{
"k": "l",
"s": "32 · Source: Dai, Jia & Yu, Fig. 10a (averages; Binance depth within $0.10 of the mid; coin-flip ÷"
},
{
"k": "l",
"s": "      decided, rescaled so bins 0-24 average ×1), Table 4 (P3, last 10 s vs bins 0-24, coin-flip vs"
},
{
"k": "l",
"s": "      decided: +19%), Table 2 (+5%, spoken)."
},
{
"k": "l",
"s": "33 · Source: Dai, Jia & Yu, Figs. 9 and 11; before launch: Table 3; after launch: Table 5; slope of"
},
{
"k": "l",
"s": "      the next 10-s Binance mid-quote return on the final 10-s return, re-drawn. Paths:"
},
{
"k": "l",
"s": "      illustration."
},
{
"k": "l",
"s": "34 · Source: Dai, Jia & Yu, pushed vs normal cycles (P3, 5-minute contracts). Push score built from"
},
{
"k": "l",
"s": "      Binance flow only."
},
{
"k": "l",
"s": "35 · Source: Dai, Jia & Yu, win rate by favourite price and push direction; favourite 90-100% ten"
},
{
"k": "l",
"s": "      seconds before the close."
},
{
"k": "l",
"s": "36 · Source: Dai, Jia & Yu, cohort P&L by trader type, gross before fees; 1,613 pushed and 14,460"
},
{
"k": "l",
"s": "      normal cycles. Wallets selected on pushed-cycle profit (≥ 5 cycles, ≥ $2,000). Per cycle ="
},
{
"k": "l",
"s": "      group total ÷ cycles."
}
],
[
{
"k": "h",
"s": "Evidence (continued)"
},
{
"k": "l",
"s": "37 · Source: Dai, Jia & Yu, Sec. 6. Both: last-10-s flow vs earlier in the cycle. 5-min: after vs"
},
{
"k": "l",
"s": "      before launch. 15-min: P2 closes vs others, net of pre-launch gap."
},
{
"k": "l",
"s": "37 · Formal estimates (Dai, Jia & Yu, Sec. 6): δ(P2, 5m∩15m) = 0.068 (s.e. 0.032) log pts ≈ +7%,"
},
{
"k": "l",
"s": "      strongly attenuated: (P2 − P1) × (15-min close − other close); y = log |net taker order flow|,"
},
{
"k": "l",
"s": "      last 10 s vs body bins; 5-minute launch: δ(P3) = 0.406 (s.e. 0.019); extra reversal after the"
},
{
"k": "l",
"s": "      close: 0.024 (s.e. 0.087), none detected."
},
{
"k": "h",
"s": "Act 4"
},
{
"k": "l",
"s": "38 · Our paper: Dai, Jia & Yu, \"Settlement Manipulation in Prediction Markets\", arXiv 2606.31675,"
},
{
"k": "l",
"s": "      submitted 30 Jun 2026 13:52 UTC; SSRN 7028398 posted 1 Jul 2026 (Wayback capture 2026-10-15)."
},
{
"k": "l",
"s": "      The abstract clause is verbatim."
},
{
"k": "l",
"s": "39 · @RuizheJia thread on X, 2026-07-07; 253,379 views as read 2026-10-27 (shown as \"253K views"
},
{
"k": "l",
"s": "      (Oct)\")."
},
{
"k": "l",
"s": "39 · Bloomberg, Cameron Fozi, 2026-07-15, \"Stanford Study Says Polymarket Crypto Bets Are Being"
},
{
"k": "l",
"s": "      Manipulated\"; on screen only the date, byline and public lead paragraph."
},
{
"k": "l",
"s": "39 · @WuBlockchain on X, 2026-07-16, \"Study Finds Signs of Manipulation in Bitcoin Bets on World's"
},
{
"k": "l",
"s": "      Largest Prediction Market\"; 11.4K views as read 2026-10-27."
}
],
[
{
"k": "h",
"s": "Act 4 (continued)"
},
{
"k": "l",
"s": "39 · Matt Levine, Bloomberg Opinion, Money Stuff, \"Tricking the AI Investors\", 2026-07-02, section"
},
{
"k": "l",
"s": "      \"Prediction market manipulation\" (names the paper and its authors),"
},
{
"k": "l",
"s": "      https://www.bloomberg.com/opinion/newsletters/2026-07-02/tricking-the-ai-investors"
},
{
"k": "l",
"s": "      (paywalled); on screen a fragment of one sentence, quoted from the newsletter text: \"...spend"
},
{
"k": "l",
"s": "      a little money to move the price of Bitcoin...\"."
},
{
"k": "l",
"s": "40 · Reply by @devjoshstevens (Polymarket VP Engineering) under a post about the study (44K views):"
},
{
"k": "l",
"s": "      \"We are in the final stages of finishing TWAP on the crypto markets; ... This will go live in"
},
{
"k": "l",
"s": "      early August\". From the presenter's own screenshot of X; URL and timestamp not yet found by a"
},
{
"k": "l",
"s": "      public route, so dated \"before launch\" by its own words."
},
{
"k": "l",
"s": "40 · @PolymarketDevs on X, 2026-07-30 13:00:59 UTC: \"To protect market integrity in our crypto"
},
{
"k": "l",
"s": "      up/down markets, we're updating how these markets resolve.\" Same day, 13:28 UTC,"
},
{
"k": "l",
"s": "      @devjoshstevens: TWAP resolution from Aug 7, 30 s for 5-minute markets."
},
{
"k": "l",
"s": "41 · Polymarket changelog, 2026-08-07: Chainlink time-weighted average price replaces the single"
},
{
"k": "l",
"s": "      snapshot, for the price to beat and the settlement price; 30 s on 5-minute markets. Changelog"
},
{
"k": "l",
"s": "      2026-08-14: 5-minute window 60 s."
},
{
"k": "l",
"s": "41 · Polymarket docs, real-time data (TWAP), read 2026-10-27: \"a fixed 60-second window\". Kalshi's"
},
{
"k": "l",
"s": "      60-second average: contract terms (CRYPTO), unchanged after August. Price path stylized."
},
{
"k": "l",
"s": "41 · Also changed: the delay on orders that take liquidity, 250 -> 50 ms (Aug 17), then 150 ms (Sep"
},
{
"k": "l",
"s": "      4); changelog."
}
],
[
{
"k": "h",
"s": "Act 4 (continued)"
},
{
"k": "l",
"s": "42 · Our rebuild from public Binance BTCUSDT 1-s data, Jan 1-Oct 23, 2026; method of V. Tsybko, 'BTC"
},
{
"k": "l",
"s": "      Minute by Minute' (Aug 28). Normal = mean of minutes 1-3 of each 5-minute cycle in that hour;"
},
{
"k": "l",
"s": "      closes :04 :09 :19 :24 :34 :39 :49 :54 only."
},
{
"k": "l",
"s": "42 · Inset: Aug 7-13 (168 h) against Mar 1-Aug 6, pooled 10-s slots: peak 1.51x at 4:20-4:29,"
},
{
"k": "l",
"s": "      closing slot 0.92x. Aug 21-Sep 30: closing 10 s 1.03x."
},
{
"k": "l",
"s": "42 · Full range drawn to Oct 23: Oct 1-23 the closing 10 s read 1.48x (Q&A). Descriptive and"
},
{
"k": "l",
"s": "      untested; dates side by side, not a cause; the Aug 17 taker-delay change is not controlled"
},
{
"k": "l",
"s": "      for."
},
{
"k": "l",
"s": "43 · Card: Kalshi launch video, 2026-01-20, prices illustrative. Rules: Kalshi contract terms"
},
{
"k": "l",
"s": "      (CRYPTO); Polymarket changelog, Aug 14, 2026."
},
{
"k": "l",
"s": "43 · Longer horizon: Dai, Jia & Yu (2026), Prop. 8 (modeled; n = ordinary spot rounds before the"
},
{
"k": "l",
"s": "      window). Window average, joint surveillance: argued, not modeled."
},
{
"k": "l",
"s": "43 · Dai, Jia & Yu (2026): (a) Prop. 3; Tab. 3. (b) Prop. 5 (model); Tab. 10: retail loss share"
},
{
"k": "l",
"s": "      70.5% vs 46.0%. (c) Tab. 9: 34.2% vs 1.0% (304 cycles)."
},
{
"k": "h",
"s": "Appendix"
},
{
"k": "l",
"s": "44 · Hedge need: dollar hedge per share ∝ φ(Φ⁻¹(p)), σ and τ fixed; at p = 0.99 it is 0.067 × the"
},
{
"k": "l",
"s": "      coin flip's (p = 0.5), shown as ~7% (our arithmetic, illustration). 99%: push-characteristics"
},
{
"k": "l",
"s": "      table."
}
],
[
{
"k": "h",
"s": "Appendix (continued)"
},
{
"k": "l",
"s": "44 · Source: Dai, Jia & Yu, push-characteristics table: favourite 90–100%, 10 s out; 304 of its"
},
{
"k": "l",
"s": "      1,584 pushes go against it (19%, ours); underdog wins 34.2% vs 1.0%."
},
{
"k": "l",
"s": "44 · Illustration: hedge need is concave in p, so with calibrated prices the band's average is at"
},
{
"k": "l",
"s": "      most the 99% value; after the push ≈ 66% (= 1 − 34.2%)."
},
{
"k": "l",
"s": "44 · Source: Dai, Jia & Yu, Sec. 6 cohort-flow figure, ALL push-up cycles, not only the 90–100%"
},
{
"k": "l",
"s": "      band: (b) makers' net Up shares; (d) Binance net flow."
},
{
"k": "l",
"s": "44 · Cycles = top tenth by closing burst, so the step is partly by selection."
},
{
"k": "l",
"s": "44 · Source: Dai, Jia & Yu, Sec. 6 hedging subsection (max loss ~$1,400; ~$1.7M step). Ratio ours;"
},
{
"k": "l",
"s": "      true scale, the $1,400 bar (1 px) drawn at 6 px."
},
{
"k": "l",
"s": "44 · Flip = a push against a 90–100% favourite, 304 of the table's 1,584 pushed cycles. Makers = the"
},
{
"k": "l",
"s": "      paper's MM cohort, identified from trading records, not intent."
},
{
"k": "l",
"s": "45 · CME VWAP: volume-weighted average of futures trades, last 30 s (NYMEX/COMEX: 60 s) · Kalshi"
},
{
"k": "l",
"s": "      rules, filings · Polymarket: Chainlink oracle · lines illustrative"
},
{
"k": "l",
"s": "46 · Publicly linked: V. Tsybko, 'BTC Minute by Minute', Aug 28 (public post, cites Dai, Jia & Yu)."
},
{
"k": "l",
"s": "      Polymarket's stated reason: \"to protect market integrity\" (Jul 30)."
},
{
"k": "l",
"s": "46 · Planned, not run; windows and placebos will be fixed before each test runs. Placebos: mid-cycle"
},
{
"k": "l",
"s": "      minute; pre-switch windows; unchanged-rule contracts."
},
{
"k": "l",
"s": "46 · Our paper: Dai, Jia & Yu, arXiv 2606.31675 (submitted June 2026; SSRN 7028398)."
}
],
[
{
"k": "h",
"s": "Appendix (continued)"
},
{
"k": "l",
"s": "46 · Also changed: taker-order delay 250 → 50 ms (Aug 17), raised to 150 ms (Sep 4); Polymarket"
},
{
"k": "l",
"s": "      changelog. Not controlled for."
},
{
"k": "l",
"s": "47 · Dai, Jia & Yu (2026): (a) Prop. 3 (settlement-time price further from the true value on"
},
{
"k": "l",
"s": "      average; sign only); Tab. 3 reversal (indirect, consistent). (b) Prop. 5 (the retail slide's"
},
{
"k": "l",
"s": "      model illustration; who pays in the data: Tab. 10, in the evidence act). (c) can be"
},
{
"k": "l",
"s": "      manipulated: Prop. 4 (the manipulator pushes in equilibrium, positive profit); in the data,"
},
{
"k": "l",
"s": "      profit-identified pushes and their footprint (Tabs. 2-9, shown in the evidence act; not"
},
{
"k": "l",
"s": "      intent). Fixes: longer contract, Props. 7-8 and the 15-minute contract, Section 6 (burst about"
},
{
"k": "l",
"s": "      +7% vs +50%: strongly attenuated, not eliminated); a harder-to-manipulate (averaged)"
},
{
"k": "l",
"s": "      settlement price is argued, not modelled (Section 7)."
},
{
"k": "l",
"s": "47 · Law: Commodity Exchange Act, Designated Contract Market Core Principle 3 (binds contracts"
},
{
"k": "l",
"s": "      listed on a CFTC-designated contract market), as quoted in the paper's introduction; the"
},
{
"k": "l",
"s": "      paper's footnote cites CFTC Staff Advisory 26-08 (2026)."
},
{
"k": "l",
"s": "48 · Source: Dai, Jia & Yu, Fig. 8 left (fig:byperiod; averages, each period ÷ its 0-250 s mean) and"
},
{
"k": "l",
"s": "      fig:reversal_uncond / Table 3, j = +1 only. Binance BTC, P1 Jul-Oct 2025 vs P3 Feb 12-Apr 8,"
},
{
"k": "l",
"s": "      2026."
},
{
"k": "l",
"s": "49 · Nobody pushes in the trader's cycle (S/03:105-113); after a sell the ask moves 0 → −0.026 (Cor"
},
{
"k": "l",
"s": "      1); rescue pays 0.372; contract worth 0.471."
}
],
[
{
"k": "h",
"s": "Appendix (continued)"
},
{
"k": "l",
"s": "50 · Model: timing and players (paper S/03:91-206); Definition 1 (S/03:211-228); Assumption 1"
},
{
"k": "l",
"s": "      (S/03:254);"
},
{
"k": "l",
"s": "51 · Model (Dai, Jia & Yu 2026): (a) Prop. 3, sign only. (b) Prop. 4(iv) zero spread in the baseline"
},
{
"k": "l",
"s": "      (odd number of rounds); Prop. 5 loss decomposition: push cost 20%, prediction-market maker's"
},
{
"k": "l",
"s": "      rent 73%, manipulator's profit 7% of the ordinary buyer's expected loss (as in the previous"
},
{
"k": "l",
"s": "      scene). (c) Prop. 4, push only when losing, interior entry; Prop. 5 positive profit; Prop."
},
{
"k": "l",
"s": "      7(1) one step short of the line. (d) Prop. 8, a long clock makes a push almost never decisive."
},
{
"k": "l",
"s": "      Footprints: Section 4, testable predictions."
},
{
"k": "l",
"s": "52 · Paper S/03, Definition 1 (211-228): (ii) makers quote at zero expected profit given beliefs,"
},
{
"k": "l",
"s": "      subject to a non-crossing book"
},
{
"k": "l",
"s": "55 · Source: Dai, Jia & Yu, Fig. 10b (averages; Polymarket Up-token depth within 5¢; coin-flip ÷"
},
{
"k": "l",
"s": "      decided, rescaled so bins 0-24 average ×1), Table 4 (P3, last 10 s vs bins 0-24, coin-flip vs"
},
{
"k": "l",
"s": "      decided: −64%)."
}
]
];
